/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-27 20:34:22
 * @Author: lydia
 * @Date: 2019-08-27 18:26:04
 */
#include <iostream>
#include <vector>
#include <stack>
using namespace std;

static char priority[128] = { 0 }; //记录符号的优先级

void priorityInit()
{
    priority['+'] = 4;
    priority['-'] = 4;
    priority['*'] = 3;
    priority['/'] = 3;
}

int priorityCompare(char opt1, char opt2)
{
    return priority[opt2] - priority[opt1];
}

int calOp(stack<int>& data, stack<int>& ops, int nowOp)
{
    int a, b, op;
    op = ops.top();
    ops.pop();

    if (data.size() > 0) {
        a = data.top();
        data.pop();
    }

    if (data.size() > 0) {
        b = data.top();
        data.pop();
    }

    switch (op) {
    case '+':
        data.push(a + b);
        break;
    case '-':
        data.push(a - b);
        break;
    case '*':
        data.push(a * b);
        break;
    case '/':
        data.push(a / b);
        break;

    default:
        break;
    }

    return 1;
}

int getRes(const vector<char>& input)
{
    if (input.size() <= 0) {
        return 0;
    }
    stack<int> data;
    //保存操作数
    stack<int> opt;
    //保存操作符

    int index = 0;
    //判断上一个是否为数字
    int tmp = 0;
    int flag = 0;
    int op;
    for (const char ch : input) {
        if (ch >= '0' && ch <= '9') { //如果是数字
            if (1 == flag) { //如果上一个还是数字
                tmp = data.top();
                data.pop();
            } else {
                tmp = 0;
            }
            flag = 1;
            tmp = 10 * tmp + ch - '0';
            data.push(tmp);
        } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') { ///如果是操作符
            flag = 0;
            while (opt.size() > 0) {
                op = opt.top();
                opt.pop();
                calOp(data, opt, ch);
            }
            opt.push(ch);
        } else {
            flag = 0;
        }
    }

    //计算剩余两个栈的内容
    tmp = data.top();
    data.pop();
    return tmp;
}

int main()
{
    vector<int> data; //数据
    vector<char> opt; //操作
    vector<char> input;
    int len, i = 0, j = 0;
    cin >> len;
    data.resize(len); //数字个数
    opt.resize(len - 1); //字符个数

    int index = 0;

    while (index < 2 * len - 1) {
        char tmp;
        cin >> tmp;
        input.push_back(tmp);
        if (tmp >= '0' && tmp <= '9') {

            data[i] = tmp - '0';
            i++;
        } else {
            opt[j] = tmp;
            j++;
        }
        index++;
    }
    int res = getRes(input);
    cout << res << "\n";
    ///test optput
    for (int val : data) {
        cout << val << "\t";
    }
    cout << endl;

    for (char val : opt) {
        cout << val << "\t";
    }
    cout << endl;

    return 0;
}