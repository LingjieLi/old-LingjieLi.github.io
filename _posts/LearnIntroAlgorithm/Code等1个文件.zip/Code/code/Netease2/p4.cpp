/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 18:58:48
 * @Author: lydia
 * @Date: 2019-09-07 18:58:48
 */
#include <iostream>
#include <vector>
#include <string>
using namespace std;

bool check(vector<vector<bool>>& card, int a, int b, int k)
{
    // 左上
    int range_i = a + k;
    int range_j = b + k;
    for (int i = a; i < range_i; i++) {
        for (int j = b; j < range_j; j++)
            if (card[i][j])
                return false;
    }

    // 右上
    range_i = a + 3 * k;
    for (int i = a + 2 * k; i < range_i; i++) {
        for (int j = b; j < range_j; j++)
            if (card[i][j])
                return false;
    }

    // 左下
    range_i = a + k;
    range_j = b + 3 * k;
    for (int i = a; i < range_i; i++) {
        for (int j = b + 2 * k; j < range_j; j++)
            if (card[i][j])
                return false;
    }

    // 右下
    range_i = a + 3 * k;
    for (int i = a + 2 * k; i < range_i; i++) {
        for (int j = b + 2 * k; j < range_j; j++)
            if (card[i][j])
                return false;
    }

    // 十字形 中间
    range_i = a + 2 * k;
    range_j = b + 3 * k;
    for (int i = a + k; i < range_i; i++) {
        for (int j = b; j < range_j; j++) {
            if (!card[i][j]) {
                return false;
            }
        }
    }

    // 十字形 上边
    range_i = a + k;
    range_j = b + 2 * k;
    for (int i = a; i < range_i; i++) {
        for (int j = b + k; j < range_j; j++) {
            if (!card[i][j]) {
                return false;
            }
        }
    }

    // 十字形 下边
    range_i = a + 3 * k;
    range_j = b + 2 * k;
    for (int i = a + 2 * k; i < range_i; i++) {
        for (int j = b + k; j < range_j; j++) {
            if (!card[i][j]) {
                return false;
            }
        }
    }

    return true;
}

vector<int> findMaxTenSign(vector<vector<bool>>& card, int n, int m)
{
    vector<int> result(4, -1);
    int MAX_K = n > m ? m / 3 : n / 3; // 求出k的变化范围

    for (int k = MAX_K; k > 0; k--) {
        // 滑动查找
        for (int i = 0; i <= n - 3 * k; i++) {
            for (int j = 0; j <= m - 3 * k; j++) {
                if (check(card, i, j, k)) {
                    result[0] = i + 1;
                    result[1] = j + 1;
                    result[2] = i + 3 * k;
                    result[3] = j + 3 * k;
                    return result;
                }
            }
        }
    }

    return result;
}

int main()
{
    int T;
    cin >> T;
    for (int i = 0; i < T; i++) {
        int n, m;
        cin >> n >> m;
        string s("");
        //        getline(cin,s);
        vector<vector<bool>> card(n);
        for (int line_i = 0; line_i < n; line_i++) {
            card[line_i].resize(m);

            cin >> s;
            //            getline(cin, s);
            for (int ch = 0; ch < m; ch++) {
                if (s[ch] == '0') {
                    card[line_i][ch] = false;
                }
                if (s[ch] == '1') {
                    card[line_i][ch] = true;
                }
            }
        }

        vector<int> result = findMaxTenSign(card, n, m);
        cout << result[0] << " " << result[1] << " "
             << result[2] << " " << result[3] << endl;
    }
    return 0;
}
