/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 21:31:34
 * @Author: 沈晓海
 * @Date: 2019-09-07 21:11:39
 */

#include <iostream>
#include <vector>

using namespace std;

int getNum(int start, int end, int k)
{
    if (end < start)
        return 0;
    if (k == 0)
        return end - start + 1; //每天都喝咖啡

    int count = 0;
    for (int i = start; i <= end; i += (k + 1)) {
        count++;
    }
    return count;
}

int main()
{
    int T;
    cin >> T;
    vector<int> res;

    for (int i = 0; i < T; i++) {
        int K, M;
        cin >> K >> M;

        vector<int> inputs(M);

        for (int j = 0; j < M; j++) {
            cin >> inputs[j];
        }

        int count = 0;
        if (M == 0) { //没有固定天数
            count = getNum(1, 30, K);
        } else {
            int start = 1;
            for (int day_num : inputs) {
                int end = day_num - (K + 1);
                //cout << start << "\t" << end << "\t" << getNum(start, end, K) << "\n";
                count += getNum(start, end, K);
                start = day_num + (K + 1);
            }
            count += getNum(start, 30, K);
            //cout << start << "\t" << 30 << "\t" << getNum(start, 30, K) << "\n";
        }

        res.push_back(count + M);
    }

    for (int val : res) {
        cout << val << "\n";
    }
}