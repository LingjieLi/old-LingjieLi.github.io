/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 19:36:10
 * @Author: lydia
 * @Date: 2019-09-07 18:58:31
 */

#include <iostream>
#include <string>

using namespace std;

string toBinary(int num)
{
    string res = "";
    while (num) {
        string tmp = to_string(num % 2);
        bool flag = true;
        for (char c : tmp) {
            res.insert(res.begin(), c);
        }
        num /= 2;
    }
    //删除前导零
    bool flag = true;
    res.reserve();
    string res2 = "";
    for (int i = 0; i < res.size(); i++) {
        if (res[i] != '0') {
            flag = false;
        }
        if (flag && res[i] == '0') {
        } else {
            res2.push_back(res[i]);
        }
    }
    //cout << res << "\n"
    //     << res2 << "\n";
    return res2;
};
bool HuiWen(string str)
{
    int i = 0, j = str.size() - 1;
    while (i < j) {
        if (str[i] != str[j]) {
            return false;
        }
        i++;
        j--;
    }
    return true;
};
int main()
{
    int T;
    cin >> T;

    int num;
    string res;
    for (int i = 0; i < T; i++) {
        cin >> num;
        res = toBinary(num);
        //cout << res << "\t";
        if (HuiWen(res)) {
            cout << "YES\n";
        } else {
            cout << "NO\n";
        }
    }
    return 0;
}