/*
 * @Description: 
 * 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 21:08:46
 * @Author: lydia
 * @Date: 2019-09-07 20:22:23
 */

#include <iostream>
#include <vector>

using namespace std;

/*
4
0 10
1 2 3 4 5 6 7 8 9 10
1 15
1 3 5 7 9 11 13 15 17 19 21 23 25 27 29
2 7
5 9 13 17 21 25 29
2 0

*/

int getRes(vector<bool> coffeeday, vector<int> data, int K, int M)
{
    if (M == 0) {
        for (int i = 1; i <= 30; i += K + 1) {
            if (i + K <= 30) {
                coffeeday[i] = true;
            }
        }
    } else if (K == 30) { //间隔为30

    } else if (M == 30) {
    } else {
        //头部
        for (int i = 1; i < data[0]; i += K + 1) { //遍历每一天
            if (i + K < data[0]) {
                coffeeday[i] = true;
            }
        }
        //中部
        for (int i = 0; i < data.size() - 1; i++) {
            //i起始日期cl
            for (int j = data[i] + K + 1; j < data[i + 1]; j += K + 1) {
                if (j + K < data[i + 1]) {
                    coffeeday[j] = true;
                }
            }
        }

        //尾部
        for (int i = *data.rbegin() + K + 1; i <= 30; i += K + 1) {
            if (i <= 30) {
                coffeeday[i] = true;
            }
        }
    }

    int num = 0;
    for (int i = 1; i <= 30; i++) {
        // cout << coffeeday[i] << " ";
        if (coffeeday[i]) {
            num++;
        }
    }
    // cout << "\n";
    cout << num << "\n";
    return num;
}

int main()
{
    vector<bool> coffeeday(31, false);
    vector<int> data;

    int T, K, M; //测试数据 间隔 固定咖啡日
    cin >> T;

    for (int i = 0; i < T; i++) {
        coffeeday.clear();
        coffeeday = vector<bool>(31, false);
        data.clear();
        cin >> K >> M;
        for (int j = 0; j < M; j++) {
            int no;
            cin >> no;
            coffeeday[no] = true;
            data.push_back(no);
        }
        getRes(coffeeday, data, K, M);
    }

    return 0;
}