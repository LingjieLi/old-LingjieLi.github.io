/*
 * @Description: 喝咖啡
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 20:21:26
 * @Author: lydia
 * @Date: 2019-09-07 18:58:41
 */

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

/**
4
0 10
1 2 3 4 5 6 7 8 9 10
1 15
1 3 5 7 9 11 13 15 17 19 21 23 25 27 29
1 7
5 9 13 17 21 25 29
1 0
**/

int main()
{
    int T, K, M; //测试数据 间隔 固定天数
    cin >> T;
    vector<int> ress;
    vector<int> input;
    for (int i = 0; i < T; i++) {
        input.clear();
        cin >> K >> M;
        for (int j = 0; j < M; j++) {
            int idx;
            cin >> idx;
            input.push_back(idx);
        }

        if (K == 30) {
            ress.push_back(0);
            continue;
        } else if (K == 0) {
            ress.push_back(30);
            continue;
        }
        if (M == 0) {
            ress.push_back(30 / (K + 1));
            continue;
        }

        //填充咖啡日
        int res = 0;
        int first = 0, second = input[0]; //第一个固定咖啡日和第二个固定咖啡日
        res += max((second - 0) / (K + 1) - 1, 0);
        for (int index = 1; index < M; index++) {
            second = input[index];
            first = input[index - 1];
            res += max((second - first) / (K + 1) - 1, 0);
        }
        res += max((30 - first) / (K + 1) - 1, 0);
        res += M;
        //cout << res << "\n";
        ress.push_back(res);
    }

    for (int val : ress) {
        cout << val << "\n";
    }
    return 0;
}
