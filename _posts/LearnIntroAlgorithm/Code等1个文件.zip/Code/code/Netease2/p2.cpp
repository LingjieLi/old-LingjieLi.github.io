/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-07 20:15:22
 * @Author: lydia
 * @Date: 2019-09-07 18:58:36
 */
#include <iostream>
#include <vector>

using namespace std;

class Tree;
class Tree {
public:
    Tree()
    {
        value = 0;
        this->left = nullptr;
        this->right = nullptr;
        this->parent = nullptr;
    }
    ~Tree()
    {
        if (left != nullptr) {
            delete left;
            left = nullptr;
        }
        if (right != nullptr) {
            delete right;
            right = nullptr;
        }
    }

    int value;
    Tree* left;
    Tree* right;
    Tree* parent;
};

Tree* createTree(vector<vector<int>>& cur_tree)
{
    vector<Tree*> map(cur_tree.size());
    for (int i = 0; i < cur_tree.size(); i++)
        map[i] = new Tree();

    for (int i = 0; i < cur_tree.size(); i++) {
        map[i]->value = cur_tree[i][0];
        if (cur_tree[i][1] != -1) {
            map[i]->left = map[cur_tree[i][1]];
            map[cur_tree[i][1]]->parent = map[i];
        }
        if (cur_tree[i][2] != -1) {
            map[i]->right = map[cur_tree[i][2]];
            map[cur_tree[i][2]]->parent = map[i];
        }
    }
    for (auto node : map) {
        if (node->parent == nullptr)
            return node;
    }
    return nullptr;
}

bool isIncreasingTree(Tree* tree)
{
    if (tree == nullptr)
        return false;

    vector<Tree*> queue_tree;
    vector<int> value;

    value.push_back(0);

    queue_tree.push_back(tree);
    queue_tree.push_back(nullptr);

    Tree* p;
    while (queue_tree.size() > 0) {
        // 出队
        p = queue_tree.front();
        queue_tree.erase(queue_tree.begin());

        if (p != nullptr) {
            value[value.size() - 1] += p->value;

            if (p->left != nullptr)
                queue_tree.push_back(p->left);
            if (p->right != nullptr)
                queue_tree.push_back(p->right);
        } else {
            // 出队
            if (queue_tree.size() > 0) {
                queue_tree.push_back(nullptr);
                value.push_back(0);
            }
        }
    }

    for (int i = 0; i < value.size() - 1; i++) {
        if (value[i] > value[i + 1])
            return false;
    }

    return true;
}

int main()
{
    int T;
    cin >> T; // T [0, 50]

    vector<int> N(T); // N [0, 1000]
    vector<vector<vector<int>>> trees(T);

    for (int i = 0; i < T; i++) {
        // N
        cin >> N[i];
        int tmp = N[i];
        trees[i] = vector<vector<int>>(tmp, vector<int>(3));
        vector<vector<int>>& cur_tree = trees[i];

        for (int j = 0; j < tmp; j++) {
            // Value LEFT RIGHT
            cin >> cur_tree[j][0] >> cur_tree[j][1] >> cur_tree[j][2];
        }
    }

    for (int i = 0; i < T; i++) {
        Tree* tree = createTree(trees[i]);
        if (isIncreasingTree(tree)) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
        delete tree;
    }

    return 0;
}
