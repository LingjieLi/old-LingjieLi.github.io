/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-15 17:26:50
 * @Author: lydia
 * @Date: 2019-08-15 16:44:19
 */

/*
1
10
140 649 340 982 105 86 56 610 340 879
*/
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int getSum(vector<int> data, int L, int R)
{
    int s = 0;
    while (L <= R) {
        s += data[L];
        L++;
    }
    return s;
}

int main()
{
    int T = 0, index = 1;
    vector<int> data;
    cin >> T;
    while (index <= T) {
        //load data
        data.clear();
        int N = 0; //length
        cin >> N;
        data.resize(N + 1);
        for (int i = 1; i <= N; i++) {
            cin >> data[i];
        }

        //dynamic program
        vector<vector<int>> dp;
        dp.resize(N + 1);
        for (vector<int>& vec : dp) {
            vec.resize(N + 1);
        }

        int L, R; //界限
        for (int round = 0; round < N; round++) {
            for (int row = 1; row < N + 1 - round; row++) {
                L = row;
                R = L + round;
                if (L == R) {
                    dp[L][R] = data[L];
                } else {
                    dp[L][R] = getSum(data, L, R) - min(dp[L + 1][R], dp[L][R - 1]);
                }
            }
        }

        cout << "Case #" << index << ": "
             << dp[1][N] << " " << getSum(data, 1, N) - dp[1][N] << "\n";

        index++;
    }
    return 1;
}
