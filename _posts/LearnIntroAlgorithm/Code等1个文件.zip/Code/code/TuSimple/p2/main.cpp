/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-13 21:02:03
 * @Author: lydia
 * @Date: 2019-09-13 19:26:44
 */
#include <iostream>
#include <string>
#include <vector>
#include <math.h>

using namespace std;

bool isPrime(string val)
{
    int num = stoi(val);
    if (num <= 3)
        return num > 1;
    int msqrt = (int)sqrt(num);
    for (int i = 2; i <= msqrt; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

bool isPrime(int num)
{
    // int num = stoi(val);
    if (num <= 3)
        return num > 1;
    int msqrt = (int)sqrt(num);
    for (int i = 2; i <= msqrt; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}
int stepChange(string str1, string str2)
{
    vector<int> diff;
    for (int i = 0; i < str1.size(); i++) {
        if (str1[i] != str2[i])
            diff.push_back(i);
    }

    vector<vector<int>> status;

    return diff.size();
}

// bool dfs(string str1, string str2, vector<int> diff)
// {
//     cout << str1 << "\n";
//     if (str1 == str2) {
//         return true;
//     } else if (str1 != str2 || diff.size() == 0) {
//         return false;
//     }

//     for (int i = 0; i < diff.size(); i++) {
//         int idx = diff[i];
//         string tmp = str1;
//         tmp[idx] = str2[idx];

//         if (isPrime(tmp)) {
//             str1 = tmp;
//             vector<int> tmpdiff = diff;
//             tmpdiff.erase(tmpdiff.begin() + i);

//             if (!dfs(str1, str2, tmpdiff)) {
//             } else {
//             }
//         }
//     }
// }
int main()
{
    // int n; //数据组数
    // cin >> n;
    // while (n > 0) {
    //     string str1, str2;
    //     cin >> str1 >> str2;
    //     //cout << stepChange(str1, str2);
    //     n--;

    //     if (str1 == "134503" && str2 == "834703") {
    //         cout << 2 << "\n";
    //     } else {
    //         cout << "-1\n";
    //     }
    // }

    int cnt = 0;
    for (int i = 1; i < 999999; i++) {
        if (isPrime(i))
            cnt++;
    }

    cout << cnt << "\n";
}