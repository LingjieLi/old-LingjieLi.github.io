/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-13 19:23:09
 * @Author: lydia
 * @Date: 2019-09-13 19:05:37
 */
#include <iostream>
#include <vector>
#include <string>

using namespace std;

/**
5 5
01000
11100
11101
11111
00101
 * */
int main()
{
    int n, m; //n行 m列
    cin >> n >> m;
    vector<vector<int>> data(n, vector<int>(m, -1));

    string line;
    getline(cin, line);
    for (int r = 0; r < n; r++) {
        getline(cin, line);
        for (int c = 0; c < m; c++) {
            data[r][c] = line[c] - '0';
        }
    }

    // for (int r = 0; r < n; r++) {
    //     for (int c = 0; c < m; c++) {
    //         cout << data[r][c] << "\t";
    //     }
    //     cout << "\n";
    // }

    int size = 0;
    for (int r = 1; r < n - 1; r++) {
        for (int c = 1; c < m - 1; c++) {
            if (data[r][c] == 1
                && data[r - 1][c] == 1
                && data[r + 1][c] == 1
                && data[r][c - 1] == 1
                && data[r][c + 1] == 1) {
                size++;
            }
        }
    }

    cout << size << "\n";
}