/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-19 20:52:08
 * @Author: lydia
 * @Date: 2019-08-19 20:49:23
 */
#include <iostream>
using namespace std;
int main(){

    int n=0,a=0,b=0,c=0,f0=0;
    cin>>n,a,b,c,f0;
    
    long long f1,f2;
    
    f1=(a*f0+32768)%1000000007;
    f2=(a*f1+b*f0+2*2*2-2+32767)%1000000007;

    if(n<0){
        cout<<0<<"\n":
    }else if(n==0){
        cout<<f0<<"\n";
    }else if(n==1){
        cout<<f1<<"\n";
    }else if(n==2){
        cout<<f2<<"\n";
    }else if(n>=3){
        long long fi,fi_1,fi_2,fi_3;
        fi_1=f2,fi_2=f1,fi_3=f0;
        long long tmp;

        for(int i=3;i<=n;i++){
            fi=((a*fi_1)%1000000007
            +(b*fi_2)%1000000007
            +(c*fi_3)%1000000007
            +2*i*i%1000000007
            -i
            +32767)%1000000007;

            fi_3=fi_2;
            fi_2=fi_1;
            fi_1=fi;
        }
        cout<<fi<<endl;
    }

    return 0;
}
