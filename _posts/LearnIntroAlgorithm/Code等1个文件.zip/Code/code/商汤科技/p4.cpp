/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-19 20:00:36
 * @Author: lydia
 * @Date: 2019-08-19 19:38:01
 */
///完全平方数

#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>

using namespace std;

bool isFullSqrt(int val){
    int t=sqrt(val);
    return t*t==val;
};
int fact(int x){
    int t=1;
    for(int i=2;i<=x;i++){
        t*=i;
    }
    return t;
}
int numberSquare(vector<int> A){
    int n=A.size();
    sort(A.begin(),A.end());

    vector<int> s;
    int cnt=1;
    for(int i=1;i<n;i++){
        if(A[i]!=A[i-1]){
            s.push_back(cnt);
            cnt=0;
        }
        cnt++;
    }
    s.push_back(cnt);

    vector<vector<int>> f(1<<n,vector<int>(n,0));

    for(int i=0;i<n;i++){
        f[1<<i][i]=1;
    }

    for(int S=1;S<1<<n;S++){
        for(int i=0;i<n;i++){
            if(S&(1<<i)){
                for(int j=0;j<n;j++){
                    if(!(S&(1<<j))&&isFullSqrt(A[i]+A[j])){
                        f[S|(1<<j)][j]+=f[S][i];
                    }
                }
            }
        }
    }

    int ans=0;
    for(int i=0;i<n;i++){
        ans+=f[(1<<n)-1][i];
    }
    for(int i=0;i<s.size();i++){
        ans/=fact(s[i]);
    }

    return ans;
}

int main(){

    int N=0;
    vector<int> data;
    cin>>N;
    data.resize(N);

    for(int i=0;i<N;i++){
        cin>>data[i];
    }

    cout<<numberSquare(data);

    return 0;
}
