/*
 * @Description: 
 * 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-24 15:52:11
 * @Author: lydia
 * @Date: 2019-08-19 20:16:42
 */
#include <iostream>
#include <vector>
#include <string>
#include <stack>

using namespace std;

bool isNum(string str)
{
    try {
        int test = std::stoi(str);
        return true;
    } catch (const std::exception&) {
        return false;
    }
}

void CalculateResult(char oper, std::stack<int>& tmpStack)
{
    if (tmpStack.size() < 2) {
        return;
    }

    int secondVal = tmpStack.top();
    tmpStack.pop();
    int firstVal = tmpStack.top();
    tmpStack.pop();

    int result = 0;
    switch (oper) {
    case '+':
        result = firstVal + secondVal;
        break;
    case '-':
        result = firstVal - secondVal;
        break;
    case '*':
        result = firstVal * secondVal;
        break;
    case '/':
        result = firstVal / secondVal;
        break;

    default:
        break;
    }
    tmpStack.push(result);
}

float getResult(std::vector<string>& strs)
{
    if (strs.size() <= 0) {
        return 0;
    }

    stack<int> tmpStack;
    for (auto obj : strs) {
        if (isNum(obj)) {
            tmpStack.push(std::stoi(obj));
        } else {
            CalculateResult(obj[0], tmpStack);
        }
    }

    return tmpStack.top();
}

int main()
{

    std::vector<string> inputs;
    std::string input;

    std::cin.getline(array, 10240);

    input = std::string(array);

    while (input.find(' ') != std::string::npos) {
        int find = input.find(' ');
        inputs.push_back(input.substr(0, find));
        input = input.substr(find + 1, input.length());
    }

    inputs.push_back(input);

    std::cout << getResult(inputs) << std::endl;

    return 0;
}