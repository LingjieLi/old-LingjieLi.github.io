/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-19 20:15:57
 * @Author: lydia
 * @Date: 2019-08-19 20:05:37
 */
///最长的山峰

#include <vector>
#include <iostream>

using namespace std;

int longestMountain(vector<int> A){
    if(A.size()<3){
        return 0;
    }

    int left[10010];
    int right[10010];

    left[0]=0;

    for(int i=0;i<A.size();i++){
        if(A[i]>A[i-1]){
            left[i]=left[i-1]+1;
        }else{
            left[i]=0;
        }
    }

    right[A.size()-1]=0;
    for(int i=A.size()-2;i>=0;i--){
        if(A[i]>A[i+1]){
            right[i]=right[i+1];
        }else{
            right[i]=0;
        }
    }

    int ans=0;
    for(int i=0;i<A.size();i++){
        if(left[i]>0&&right[i]>0&&left[i]+right[i]+1>ans){
            ans=left[i]+right[i]+1;
        }
    }

    return ans;
}

int main(){
    int N;
    vector<int> data;
cin>>N;
    data.resize(N);
    for(int i=0;i<N;i++){
        cin>>data[i];
    }
    
    cout<<longestMountain(data);

    return 0;
}