/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-10 21:00:39
 * @Author: lydia
 * @Date: 2019-08-10 20:59:31
 */
#include <vector>

using namespace std;
class Solution {
public:
    void getMaxTree(vector<int> arr){

    };
};