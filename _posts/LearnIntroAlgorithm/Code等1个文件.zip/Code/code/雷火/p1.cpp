//矩形排序

#include <iostream>
#include <algorithm>
#include <math.h>
#include <vector>

using namespace std;

struct Rectangle {
    int W;
    int H;
    float aspectRatio;

    Rectangle(int _W, int _H)
        : W(_W)
        , H(_H)
    {
        if (W * 1.0 / H < H * 1.0 / W) {
            aspectRatio = W * 1.0 / H;
        } else {
            aspectRatio = H * 1.0 / W;
        }
    };
};
// 用自定义函数对象排序
struct {
    bool operator()(Rectangle a, Rectangle b) const
    {
        if (a.H * a.W != b.H * b.W) {
            return a.H * a.W < b.H * b.W;
        } else if (a.aspectRatio != b.aspectRatio) {
            return a.aspectRatio > b.aspectRatio;
        } else {
            return a.W < b.W;
        }
    }
} customLess;
int main()
{

    int N;
    cin >> N;
    vector<Rectangle> data;

    for (int i = 0; i < N; i++) {
        int W, H;
        cin >> W >> H;
        Rectangle rec(W, H);
        data.push_back(rec);
    }

    sort(data.begin(), data.end(), customLess);

    for (Rectangle rec : data) {
        cout << rec.W << " " << rec.H << " ";
    }
    cout << "\n";

    return 0;
}