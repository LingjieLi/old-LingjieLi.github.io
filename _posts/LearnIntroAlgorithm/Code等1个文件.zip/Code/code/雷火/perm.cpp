
#include <iostream>
#include <vector>
using namespace std;

void dfs(int pos, int cnt, int n, int k, vector<int> a, vector<bool> visited, vector<vector<int>>& res)
{
    //已标记了k个数，输出结果
    if (cnt == k) {
        // for (int i = 0; i < n; i++)
        //     if (visited[i])
        //         cout << a[i] << ' ';
        // cout << endl;
        vector<int> tres;
        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                tres.push_back(a[i]);
            }
        }
        res.push_back(tres);
        return;
    }

    //处理到最后一个数，直接返回
    if (pos == n)
        return;

    //如果a[pos]没有被选中
    if (!visited[pos]) {
        //选中a[pos]
        visited[pos] = true;
        //处理在子串a[pos+1, n-1]中取出k-1个数的子问题
        dfs(pos + 1, cnt + 1, n, k, a, visited, res);
        //回溯
        visited[pos] = false;
    }
    //处理在子串a[pos+1, n-1]中取出k个数的问题
    dfs(pos + 1, cnt, n, k, a, visited, res);
}
//C(n,k)
void perm(int n, int k, vector<vector<int>>& res)
{
    // int i, n, k;
    // bool* visited = new bool[n];
    // for (i = 0; i < n; i++) {
    //     a[i] = i + 1;
    //     visited[i] = false;
    // }
    vector<int> a;
    a.resize(n);
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }

    vector<bool> visited(n, false);

    dfs(0, 0, n, k, a, visited, res);
}
int main()
{
    int i, n, k;
    while (cin >> n >> k, n || k) {
        int* a = new int[n];
        bool* visited = new bool[n];
        for (i = 0; i < n; i++) {
            a[i] = i + 1;
            visited[i] = false;
        }
        vector<vector<int>> res;
        //dfs(0, 0, n, k, a, visited, res);
        perm(n, k, res);
        for (int i = 0; i < res.size(); i++) {
            for (int j = 0; j < res[i].size(); j++) {
                cout << res[i][j] << "\t";
            }
            cout << "\n";
        }
        delete[] a;
        delete[] visited;
    }
    getchar();
    return 0;
}