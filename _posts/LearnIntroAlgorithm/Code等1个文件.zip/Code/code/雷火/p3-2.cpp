#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

//data
struct Node {
    int delaytime = 0;
    int usedtime = 0;
};

struct Work {
    int cost = 0; //花费时间
    int deadline = 0;
    Work(int _deadline, int _cost)
        : deadline(_deadline)
        , cost(_cost){};
    Work(){};
};

vector<Work> worklist; //任务
vector<vector<Node>> dp; //dp矩阵
vector<vector<int>> rowHead; //行头
int rows, cols;

void perm_dfs(int pos, int cnt, int n, int k, vector<int> a, vector<bool> visited, vector<vector<int>>& res)
{
    //已标记了k个数，输出结果
    if (cnt == k) {
        // for (int i = 0; i < n; i++)
        //     if (visited[i])
        //         cout << a[i] << ' ';
        // cout << endl;
        vector<int> tres;
        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                tres.push_back(a[i]);
            }
        }
        res.push_back(tres);
        return;
    }

    //处理到最后一个数，直接返回
    if (pos == n)
        return;

    //如果a[pos]没有被选中
    if (!visited[pos]) {
        //选中a[pos]
        visited[pos] = true;
        //处理在子串a[pos+1, n-1]中取出k-1个数的子问题
        perm_dfs(pos + 1, cnt + 1, n, k, a, visited, res);
        //回溯
        visited[pos] = false;
    }
    //处理在子串a[pos+1, n-1]中取出k个数的问题
    perm_dfs(pos + 1, cnt, n, k, a, visited, res);
}
//C(n,k)  {1,2,3,...,n}
vector<vector<int>> perm(int n, int k)
{
    vector<vector<int>> res;

    vector<int> a;
    a.resize(n);
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }

    vector<bool> visited(n, false);
    perm_dfs(0, 0, n, k, a, visited, res);

    return res;
}

//print worklist
void print_worklist()
{
    for (Work w : worklist) {
        cout << w.deadline << "," << w.cost << "\n";
    }
}
void print_rowhead()
{
    cout << "\t";
    for (vector<int> val : rowHead) {
        cout << "{";
        for (int i = 0; i < val.size() - 1; i++) {
            cout << val[i] << ",";
        }
        cout << "}\t";
    }
}
int main()
{
    //input
    int n;
    cin >> n;
    rows = n + 1;
    cols = pow(2, n); //C(n,0)+C(n,1)+...+C(n,n)
    worklist.resize(n + 1);
    for (int i = 1; i <= n; i++) {
        int deadline, cost;
        cin >> deadline >> cost;
        Work w(deadline, cost);
        worklist[i] = w;
    }
    cout << rowHead.size() << "\n";
    //初始化rowHead
    for (int r = 0; r < rows; r++) {
        vector<vector<int>> temp = perm(n, r);
        rowHead.insert(rowHead.end(), temp.begin(), temp.end());
    }

    print_worklist();
    print_rowhead();

    return 0;
}