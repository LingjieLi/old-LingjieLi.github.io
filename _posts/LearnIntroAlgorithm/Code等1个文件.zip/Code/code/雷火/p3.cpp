#include <vector>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

struct Work {
    int start;
    int deadline;
    int cost;

    Work(int _deadline, int _cost)
        : deadline(_deadline)
        , cost(_cost)
    {
    }
};

struct Node {
    int delaytime = 0;
    int usedtime = 0;
};

vector<vector<Node>> dp;
vector<vector<int>> rowhead;
vector<Work> worklist;

//Cni
int pailie(int n, int i)
{
    int res = 1;
    for (int j = 1; j <= n; j++) {
        res *= j;
    }
    int fenmu = 1;
    for (int j = 1; j <= i; j++) {
        fenmu *= j;
    }
    for (int j = 1; j <= n - i; j++) {
        fenmu *= j;
    }

    return res / fenmu;
};

//C(n,k)
void dfs(int pos, int cnt, int n, int k, vector<int> a, vector<bool> visited, vector<vector<int>>& res)
{
    //已标记了k个数，输出结果
    if (cnt == k) {
        // for (int i = 0; i < n; i++)
        //     if (visited[i])
        //         cout << a[i] << ' ';
        // cout << endl;
        vector<int> tres;
        for (int i = 0; i < n; i++) {
            if (visited[i]) {
                tres.push_back(a[i]);
            }
        }
        res.push_back(tres);
        return;
    }

    //处理到最后一个数，直接返回
    if (pos == n)
        return;

    //如果a[pos]没有被选中
    if (!visited[pos]) {
        //选中a[pos]
        visited[pos] = true;
        //处理在子串a[pos+1, n-1]中取出k-1个数的子问题
        dfs(pos + 1, cnt + 1, n, k, a, visited, res);
        //回溯
        visited[pos] = false;
    }
    //处理在子串a[pos+1, n-1]中取出k个数的问题
    dfs(pos + 1, cnt, n, k, a, visited, res);
}
//C(n,k)
void perm(int n, int k, vector<vector<int>>& res)
{
    // int i, n, k;
    // bool* visited = new bool[n];
    // for (i = 0; i < n; i++) {
    //     a[i] = i + 1;
    //     visited[i] = false;
    // }
    vector<int> a;
    a.resize(n);
    for (int i = 0; i < n; i++) {
        a[i] = i + 1;
    }

    vector<bool> visited(n, false);

    dfs(0, 0, n, k, a, visited, res);
}

bool isInclude(vector<int> vec, int val)
{
    if (find(vec.begin(), vec.end(), val) != vec.end()) {
        return true; //包含
    }
    return false; //不包含
};

int findCol(vector<int> val, vector<vector<int>> data)
{

    if (val.empty()) {
        return 0;
    }
    sort(val.begin(), val.end());
    for (int i = 0; i < data.size(); i++) {
        if (data[i].size() == val.size()) {
            vector<int> tmp = data[i];
            sort(tmp.begin(), tmp.end());
            if (val == tmp) {
                return i;
            }
        }
    }

    return -1;
}

//当前节点 当前路径 当前节点所在行和列
void calculateRouteDelay(int r, int c)
{
    int curNode = r;
    vector<int> route = rowhead[c];
    //开始计算这条路径上的结果
    int curDalay = INT32_MAX;
    int curUsed = INT32_MAX;
    for (int i = 0; i < route.size(); i++) {
        int lastNode = route[i]; //假设选择的下一个工作是这个
        vector<int> tmproute = route;
        tmproute.erase(tmproute.begin() + i);
        //找到temproute所在的列
        int col = findCol(tmproute, rowhead);
        if (col != -1) {
            //dp[lastNode][col]
            int lastUsed = dp[lastNode][col].usedtime;
            int thisUsed = lastUsed + worklist[curNode - 1].cost;
            if (curUsed > thisUsed) {
                curUsed = thisUsed;
                curDalay = thisUsed - worklist[curNode - 1].deadline > 0 ? thisUsed - worklist[curNode - 1].deadline : 0;
                curDalay += dp[lastNode][col].delaytime;
            }
        } else {
            cout << "error\n";
        }
    }
    dp[r][c].delaytime = curDalay;
    dp[r][c].usedtime = curUsed;
}
int main()
{
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        int deadline, cost;
        cin >> deadline >> cost;
        Work w(deadline, cost);
        worklist.push_back(w);
    }
    int rows = n + 1;
    int cols = pow(2, n);
    Node node;
    dp = vector<vector<Node>>(rows, vector<Node>(cols, node)); //n+1 * 2^n
    //vector<vector<int>> rowhead;
    rowhead.resize(cols);
    // //第一列为空
    int tmp = 1;
    for (int i = 1; i < cols;) {
        vector<vector<int>> pailie;
        perm(n, tmp, pailie); //C(n,tmp)
        int size = pailie.size();
        for (int j = 0; j < size; j++, i++) {
            rowhead[i] = pailie[j];
        }

        tmp++;
    }

    // cout << "rowhead:\n";
    // for (int i = 0; i < rowhead.size(); i++) {
    //     for (int j = 0; j < rowhead[i].size(); j++) {
    //         cout << rowhead[i][j] << "\t";
    //     }
    //     cout << "\n";
    // }

    // for (Work w : worklist) {
    //     cout << w.deadline << "," << w.cost << "\n";
    // }

    //初始化第一列
    for (int r = 1; r < rows; r++) {
        dp[r][0].delaytime = 0;
        dp[r][0].usedtime = worklist[r - 1].cost;
    }
    for (int v_size = 1; v_size <= n; v_size++) { //可选集合由小到大,
        for (int c = 1; c < cols; c++) {
            int mindelay = INT32_MAX;
            if (rowhead[c].size() == v_size) {
                for (int r = 1; r < rows; r++) {
                    //判断是否包含
                    if (!isInclude(rowhead[c], r)) { //不包含可以计算
                        //dp[r][c] = ;
                        calculateRouteDelay(r, c);
                    }
                }
            }
        }
    }

    //计算最后一个点
    int delay = INT32_MAX;
    vector<int> lastHead = rowhead[cols - 1];
    for (int r = 1; r < rows; r++) {
        vector<int> tmproute = lastHead;
        tmproute.erase(tmproute.begin() + r - 1);
        int col = findCol(tmproute, rowhead);
        //cout << "col:" << col << "\n";
        int curDelay = dp[r][col].delaytime;
        if (curDelay < delay) {
            delay = curDelay;
        }
    }

    cout << delay << "\n";

    cout << "\t";
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < rowhead[c].size(); i++) {
            cout << rowhead[c][i] << ",";
        }
        cout << "\t";
    }
    cout << endl;
    for (int r = 0; r < rows; r++) {
        cout << r << "\t";
        for (int c = 0; c < cols; c++) {
            cout << "(" << dp[r][c].usedtime << "," << dp[r][c].delaytime << ")"
                 << "\t";
        }
        cout << "\n";
    }
    cout << "\n";
    return 0;
}