#include <vector>
#include <iostream>
#include <stack>

using namespace std;

/*
5
1 2 -3
1 3 2
2 4 6
2 5 -3
*/

struct TreeNode {
    int idx;
    vector<TreeNode*> childs;
    vector<int> weight;
    int weightsum = INT32_MIN;

    TreeNode(int _idx)
        : idx(_idx){};
    TreeNode(){};
};

void dfs(TreeNode* pRoot)
{
    int weightsum = INT32_MIN;
    if (pRoot->childs.size() > 0) {
        for (int i = 0; i < pRoot->childs.size(); i++) {
            dfs(pRoot->childs[i]);
        }

        int maxweightsum = INT32_MIN;
        for (int i = 0; i < pRoot->childs.size(); i++) {
            int tempweightsum = 0;
            if (pRoot->childs[i]->weightsum > 0) {
                tempweightsum = pRoot->childs[i]->weightsum;
            } else {
            }
            if (pRoot->weight[i] + tempweightsum > maxweightsum) {
                maxweightsum = pRoot->weight[i] + tempweightsum;
            }
        }
        if (maxweightsum > 0) {
            pRoot->weightsum = maxweightsum;
        } else {
            pRoot->weightsum = 0;
        }
    } else {
        pRoot->weightsum = 0;
    }
}
int main()
{
    int n; //节点个数
    cin >> n;
    vector<TreeNode*> data(n + 1, nullptr);

    for (int i = 0; i < n - 1; i++) {
        long long u, v, c;
        cin >> u >> v >> c;
        if (data[u] == nullptr) {
            data[u] = new TreeNode(u);
        }
        if (data[v] == nullptr) {
            data[v] = new TreeNode(v);
        }

        data[u]->childs.push_back(data[v]);
        data[u]->weight.push_back(c);
    }

    dfs(data[1]);

    for (TreeNode* node : data) {
        if (node == nullptr)
            continue;
        cout << node->weightsum << " ";
    }
    cout << "\n";

    return 0;
}