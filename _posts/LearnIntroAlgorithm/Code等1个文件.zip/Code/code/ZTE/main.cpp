/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-09-09 10:04:44
 * @Author: lydia
 * @Date: 2019-09-09 10:04:44
 */
#include <iostream>

#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

struct Node {
    int idx = -1;
    vector<int> child;
    vector<int> oils;
    int moil = 0;
};
int dfs(vector<Node*>& data, int idx)
{
    int cSize = data[idx]->child.size();
    int numOil = 0;
    if (cSize > 0) {
        for (int i = 0; i < cSize; i++) {
            numOil += min(data[idx]->oils[i], dfs(data, data[idx]->child[i])); //顶点最大流量
        }
    } else {
        return INT32_MAX;
    }
    return numOil;
}

int calculateMaxOil(int numNodes, int sourceNode, vector<vector<int>>& network)
{
    vector<Node*> data{ numNodes + 1, nullptr };

    for (vector<int> val : network) {
        if (data[val[0]] == nullptr) {
            data[val[0]] = new Node;
            data[val[0]]->idx = val[0];
        }

        if (data[val[1]] == nullptr) {
            data[val[1]] = new Node;
            data[val[1]]->idx = val[1];
        }
        data[val[0]]->child.push_back(val[1]);
        data[val[0]]->oils.push_back(val[2]);
    }

    //Node* pRoot = data[sourceNode];

    int res = dfs(data, sourceNode);
    //cout << res << "\n";
}

int main()
{
    int numNode = 6;
    int sourceNode = 4;
    vector<vector<int>> network{
        { 4, 2, 10 },
        { 4, 6, 20 },
        { 4, 1, 30 },
        { 1, 3, 50 },
        { 1, 5, 80 }
    };

    calculateMaxOil(numNode, sourceNode, network);

    return 0;
}