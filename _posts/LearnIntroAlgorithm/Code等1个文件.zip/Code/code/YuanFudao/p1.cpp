/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-24 17:26:44
 * @Author: lydia
 * @Date: 2019-08-24 15:52:38
 */
// /*
//  * @Description:
//*@LastEditors : lydia* @LastEditTime : 2019 - 08 - 24 16 : 34 : 19
//  * @Author: lydia
//  * @Date: 2019-08-24 15:52:38
//  */

// #include <cstdio>
// int fun1(int i)
// {
//     return i <= 5 ? i : fun1(i - 1) * fun1(i - 3);
// }

// int fun2(unsigned int i)
// {
//     return ((i >> 8) & 0x6597) & (((i << 8) & 0x6597) >> 8);
// }

// int main()
// {
//     int n = fun2(fun1(101)) % 4;
//     printf("%d", n);
//     return 0;
// }

#include <iostream>
#include <string>
#include <vector>
#include <math.h>
using namespace std;

vector<vector<int>> zuhe(vector<int> in, int target)
{ //target 是希望选择M个作组合,in是选择的范围，长度为N
    vector<vector<int>> output;
    for (int i = 0; i < pow(2, in.size()); i++) {
        int temp = 0, count = 0;
        vector<int> weishu;
        for (int j = 0; j < in.size(); j++) {
            if ((i & (1 << j)) != 0) {
                weishu.push_back(j);
                count++;
            } //找出二进制为1的位数以及它们的位置
        }
        if (count == target) { //位数等于M
            vector<int> one_case;
            for (int j = 0; j < count; j++) {
                temp = in.size() - 1 - weishu[j];
                one_case.push_back(in[temp]);
            }
            output.push_back(one_case);
        }
    }
    return output;
}

int main()
{
    int N, M, K;
    cin >> N >> M >> K;
    vector<string> stepdata; //某一步骤的数据
    //vector<vector<string>> sumdata; //所有步骤的数据

    string str1, str2;
    cin >> str1 >> str2;

    vector<int> data;
    for (int i = 0; i < N; i++) {
        data.push_back(i);
    }
    vector<vector<int>> zuhedata = zuhe(data, K);

    stepdata.push_back(str1);
    for (int step = 0; step < M; step++) {
        vector<string> tmpdata;
        for (string tstr1 : stepdata) {
            for (vector<int> val : zuhedata) { ///每一种方法
                for (int idx : val) {
                    string tmpstr1 = tstr1;
                    switch (str1[idx]) {
                    case 'A':
                        tmpstr1[idx] = 'B';
                        tmpdata.push_back(tmpstr1);
                        tmpstr1[idx] = 'C';
                        tmpdata.push_back(tmpstr1);
                        break;
                    case 'B':
                        tmpstr1[idx] = 'A';
                        tmpdata.push_back(tmpstr1);
                        tmpstr1[idx] = 'C';
                        tmpdata.push_back(tmpstr1);
                        break;
                    case 'C':
                        tmpstr1[idx] = 'B';
                        tmpdata.push_back(tmpstr1);
                        tmpstr1[idx] = 'A';
                        tmpdata.push_back(tmpstr1);
                        break;
                    default:
                        break;
                    }
                }
            }
        }
        stepdata = tmpdata;
    }

    int size = 0;
    for (string val : stepdata) {
        if (val == str2) {
            size++;
        }
    }

    cout << size % 1000000007;

    return 0;
}