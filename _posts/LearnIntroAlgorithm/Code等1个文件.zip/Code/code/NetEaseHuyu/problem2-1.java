/*
 * @Description: 
 * @LastEditors: lydia
 * @LastEditTime: 2019-08-11 15:55:47
 * @Author: lydia
 * @Date: 2019-08-11 15:53:39
 */
import java.util.Scanner;

public class Main{
    public static void main(String args){
        Scanner scanner= new Scanner(System.in)           
        int T=scanner.nextInt();
        
    
    }
}
